#include "monitor.h"

#include <math.h>
#include <stdio.h>
#include "esp_attr.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sdkconfig.h"

#include "core/board.h"
#include "core/board_config.h"
#include "core/dust.h"
#include "core/energy.h"
#include "core/ota_guard.h"
#include "core/psu.h"
#include "core/settings.h"
#include "core/tuner.h"
#include "core/state.h"
#include "core/intelligence.h"
#include "core/turbo.h"
#include "hw/purifier.h"
#include "hw/sensors.h"
#include "mining/miner.h"
#include "net/notify.h"
#include "net/price.h"
#include "net/wifi.h"

static const char *TAG = "monitor";

#define VR_FAN_TARGET_C AF_VR_FAN_TARGET_C  // per board, 65 C unless board_config.h says otherwise
#define COOLDOWN_HYST_C 20.0f
#define RECOVERY_FREQ_DROP 50
#define MAX_FAULT_RETRIES 3
#define MAX_OVERHEAT_RETRIES 3
#define MAX_RESUME_TRIES 5   // power-ups after a price pause before it counts as a fault
#define RESUME_WAIT_S 60
#define RECOVERY_WAIT_S 30  // between recovery attempts, so a failing power-up is not hammered
#define SENSOR_LOSS_S 3  // consecutive failed temperature reads before cutting power
// Over-temperature and over-power cut-offs need this many consecutive readings:
// a single corrupted sensor read must not shut the miner down.
#define CRIT_CONFIRM_S 2
// Powered, past start-up, and the core reads under half its set voltage this long:
// the regulator dropped out (a tripped domain, say) while everything else looks fine.
#define VOUT_SETTLE_S 10
#define VOUT_LOST_S 5
// A fan driven at least this hard but turning slower than this, for this long, has
// stalled. Only fans seen spinning since boot count: a fan that is not fitted reads
// 0 rpm too, and must not keep a one-fan miner from running.
#define FAN_STALL_MIN_DUTY 30.0f
#define FAN_STALL_RPM 300
#define FAN_STALL_S 10
// Fans need more to start than to run: some stop at the 30% floor from a cold
// start. Both get a burst at 100% after every power-up, a fan that reads stopped
// gets one before it counts as stalled, and a fan that came back from a kick runs
// a step higher for the rest of the session.
#define FAN_START_KICK_S 5
#define FAN_KICK_S 4
#define FAN_FLOOR_STEP 10
#define FAN_FLOOR_MAX 60
// Within this many degrees of the tuner's ceiling the fans go to 100%, whatever the
// fan target says: the tuner must never back off for heat while cooling is left.
#define FAN_BOOST_MARGIN_C 3.0f

// Small PI controller; output is fan duty in percent.
struct FanPI {
    float integral = 0;
    float update(float temp, float target, float min_pct)
    {
        if (temp <= 0) return 100;  // sensor lost: fail safe
        float err = temp - target;
        integral += err * 0.5f;
        if (integral < -40) integral = -40;
        if (integral > 100) integral = 100;
        float out = 50 + err * 6.0f + integral;
        if (out < min_pct) out = min_pct;
        if (out > 100) out = 100;
        return out;
    }
};

// The last emergency, with the readings that caused it. Kept in RTC memory, so it
// survives software restarts and crashes (not a power cut) and the next boot can
// still say what happened.
#define EMERGENCY_NOTE_MAGIC 0x454d4752
static RTC_NOINIT_ATTR struct {
    uint32_t magic;
    uint32_t count;
    char text[140];
} s_note;

static void emergency(SysStatus status, const char *why)
{
    if(turbo::unlocked())turbo::disarm(turbo::Reason::Supply); // stock point before any Safe Recovery retry
    // whatever else was pending belongs to the power-up being cut now
    g_state.chip_stall = 0;
    g_state.no_hash = false;
    ESP_LOGE(TAG, "EMERGENCY: %s", why);
    if (s_note.magic != EMERGENCY_NOTE_MAGIC) s_note.count = 0;
    s_note.count++;
    snprintf(s_note.text, sizeof(s_note.text), "%s | chip %.1fC, VR %.1fC, %.1f W, %.2f V in, %u MHz @ %u mV, up %lus",
             why, g_state.chip_temp_max, g_state.vr_temp, g_state.pin, g_state.vin, board::freq_mhz(), board::core_mv(),
             (unsigned long) g_state.uptime_s);
    s_note.magic = EMERGENCY_NOTE_MAGIC;
    ESP_LOGE(TAG, "readings: %s", s_note.text);
    miner::pause(true);
    board::shutdown();
    g_state.status = status;
    snprintf(g_state.fault, sizeof(g_state.fault), "%s", why);
    notify::post(NOTIFY_FAULT, "power cut: %s (chip %.0f C, VR %.0f C, %.0f W)", why, g_state.chip_temp_max,
                 g_state.vr_temp, g_state.pin);
}

static bool s_start_paused = false;

static void monitor_task(void *)
{
    FanPI asic_pi, vr_pi;
    int tick = 0;
    int fault_retries = 0;
    int overheat_retries = 0, recovery_wait = 0;
    int sensor_bad = 0;
    int crit_chip = 0, crit_vr = 0, crit_power = 0;
    int powered_s = 0, vout_low = 0;
    int stall[2] = {0, 0};
    int kick[2] = {0, 0};            // seconds left at 100% for this fan
    bool kicked[2] = {false, false}; // this stop already had its kick
    float fan_floor[2] = {0, 0};     // raised after a kick brought the fan back
    bool was_powered = false;
    bool price_paused = s_start_paused;  // chips off on purpose: price limit, or the Bitair's panel
    int resume_fails = 0, resume_wait = 0;
    char why[64];

    while (true) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        g_state.uptime_s++;
        board::read_telemetry();
        g_state.telemetry_ms.store((uint32_t)(esp_timer_get_time() / 1000));
        psu::tick();
        ota_guard::tick();
        energy::tick();
        if (g_state.uptime_s % 60 == 0) dust::tick_minute();
        Settings &cfg = settings::get();
        const board::Limits &lim = board::limits();
        bool sensors_ok = g_state.temp_ok && g_state.vr_temp_ok;

        // A header counts as connected once its fan has been seen spinning; an
        // empty header reads 0 rpm and must not trip the stall check.
        for (int i = 0; i < 2; i++) {
            if (g_state.fan_rpm[i] >= FAN_STALL_RPM && !g_state.fan_present[i]) {
                g_state.fan_present[i] = true;
                ESP_LOGI(TAG, "fan %d connected (%u rpm)", i + 1, g_state.fan_rpm[i]);
            }
        }
        if (g_state.uptime_s == 60) {
            for (int i = 0; i < 2; i++)
                if (!g_state.fan_present[i]) ESP_LOGW(TAG, "fan header %d: nothing connected (0 rpm since boot)", i + 1);
        }

        if (!board::is_powered()) powered_s = vout_low = 0, was_powered = false;
        if (board::is_powered()) {
            if (!was_powered) kick[0] = kick[1] = FAN_START_KICK_S;  // start from a firm spin
            was_powered = true;
            // a lost sensor reads as -1 here, which the PI treats as "full fan"
            float a = asic_pi.update(g_state.temp_ok ? g_state.chip_temp_max : -1, cfg.fan_target_c,
                                     fmaxf(cfg.fan_min_pct, fan_floor[0]));
            float v = vr_pi.update(g_state.vr_temp_ok ? g_state.vr_temp : -1, VR_FAN_TARGET_C,
                                   fmaxf(cfg.fan_min_pct, fan_floor[1]));
#if AF_HEX_FAMILY
            // both Hex fans blow across chips and regulator alike
            float duty[2] = {v > a ? v : a, v > a ? v : a};
#else
            float duty[2] = {a, v > a ? v : a};  // header 1: ASIC fan, header 2: VR fan
#endif
            // manual headers hold their duty, except when the miner needs the air:
            // lost sensors and the last few degrees before a ceiling always mean 100 %
            for (int i = 0; i < 2; i++)
                if (cfg.fan_mode[i] == 1) duty[i] = sensors_ok ? cfg.fan_manual[i] : 100;
            // Optional extra floor for the one-fan Gamma. Never reduces stock duty, never overrides manual mode.
            if (cfg.fan_mode[0] == 0) duty[0] = fmaxf(duty[0], intel::fan_floor());
            if (g_state.chip_temp_max >= CONFIG_AF_MAX_CHIP_TEMP - FAN_BOOST_MARGIN_C) duty[0] = duty[1] = 100;
            if (g_state.vr_temp >= lim.vr_ceil_c - FAN_BOOST_MARGIN_C) duty[1] = 100;
            // Bitair: the fan the purifier panel asked for is the least it gets
            float panel = purifier::fan_floor_pct();
            for (int i = 0; i < 2; i++) {
                if (kick[i] > 0) duty[i] = 100;
                if (duty[i] < panel) duty[i] = panel;
                fan::set_pct(i, duty[i]);
                g_state.fan_duty[i] = (uint8_t) duty[i];
            }
            g_state.fan_pct = (uint8_t) duty[0];

            // Extra experimental fail-safe; original hard limits remain below unchanged.
            auto trip=turbo::monitor_trip();
            if(trip!=turbo::Reason::None){turbo::disarm(trip);emergency(SysStatus::Fault,"TURBO watchdog / PSU budget");continue;}
            // ---- hard limits: these cut power, no questions asked ----
            if (g_state.chip_stall) {
                // 1-based, like the ASIC numbers on the screen and in the web UI
                snprintf(why, sizeof(why), "ASIC %d stopped hashing", g_state.chip_stall);
                g_state.chip_stall = 0;
                emergency(SysStatus::Fault, why);
                continue;
            }
            if (g_state.no_hash) {
                g_state.no_hash = false;
                emergency(SysStatus::Fault, "No chip is hashing");
                continue;
            }
            float set_v = board::core_mv() / 1000.0f;
            // a failed read is NAN and doesn't count either way (a busy bus is not a lost rail)
            if (!isnan(g_state.vout))
                vout_low = ++powered_s > VOUT_SETTLE_S && set_v > 0 && g_state.vout < 0.5f * set_v ? vout_low + 1 : 0;
            if (vout_low >= VOUT_LOST_S) {
                snprintf(why, sizeof(why), "Core voltage lost (%.2f V of %.2f V)", g_state.vout, set_v);
                board::log_regulator(why);  // before the cut-off clears what it says
                vout_low = 0;
                emergency(SysStatus::Fault, why);
                continue;
            }
            fan::check();  // re-applies the fan setup if the controller lost it
            // With one temperature sensor, a dead fan over the far chips would only
            // show up once they were already too hot.
            int stalled = -1;
            for (int i = 0; i < 2; i++) {
                bool slow = g_state.fan_present[i] && duty[i] >= FAN_STALL_MIN_DUTY && g_state.fan_rpm[i] < FAN_STALL_RPM;
                if (kick[i] > 0) {
                    kick[i]--;
                    if (kicked[i] && !slow) {
                        // the kick brought it back: it was stopping at its floor, so raise that
                        fan_floor[i] = fminf(fmaxf(fan_floor[i], (float) cfg.fan_min_pct) + FAN_FLOOR_STEP, FAN_FLOOR_MAX);
                        ESP_LOGW(TAG, "fan %d turns again after a kick (%u rpm): its floor is %.0f%% until the next boot", i + 1,
                                 g_state.fan_rpm[i], fan_floor[i]);
                        kicked[i] = false;
                        kick[i] = 0;
                    }
                    stall[i] = 0;
                    continue;
                }
                if (slow && !kicked[i]) {
                    ESP_LOGW(TAG, "fan %d reads %u rpm at %.0f%%: 100%% for %d s before calling it stalled", i + 1,
                             g_state.fan_rpm[i], duty[i], FAN_KICK_S);
                    kick[i] = FAN_KICK_S;
                    kicked[i] = true;
                    stall[i] = 0;
                    continue;
                }
                if (!slow) kicked[i] = false;  // turning normally: the next stop gets its own kick
                stall[i] = slow ? stall[i] + 1 : 0;
                if (stall[i] >= FAN_STALL_S) stalled = i;
            }
            if (stalled >= 0) {
                snprintf(why, sizeof(why), "Fan %d stalled (%u rpm at %.0f%%)", stalled + 1, g_state.fan_rpm[stalled],
                         duty[stalled]);
                stall[0] = stall[1] = 0;
                emergency(SysStatus::Fault, why);  // shutdown also runs both fans at 100%
                continue;
            }
            sensor_bad = sensors_ok ? 0 : sensor_bad + 1;
            if (sensor_bad >= SENSOR_LOSS_S) {
                snprintf(why, sizeof(why), "%s temperature sensor not responding", g_state.temp_ok ? "VR" : "Chip");
                emergency(SysStatus::Fault, why);
                continue;
            }
            crit_chip = g_state.chip_temp_max >= CONFIG_AF_CRIT_CHIP_TEMP ? crit_chip + 1 : 0;
            crit_vr = g_state.vr_temp >= lim.vr_crit_c ? crit_vr + 1 : 0;
            crit_power = g_state.pin > lim.max_power_w * 1.15f ? crit_power + 1 : 0;
            if (crit_chip >= CRIT_CONFIRM_S) {
                snprintf(why, sizeof(why), "Chip %.0fC >= %dC", g_state.chip_temp_max, CONFIG_AF_CRIT_CHIP_TEMP);
                crit_chip = crit_vr = crit_power = 0;
                emergency(SysStatus::Overheat, why);
                continue;
            }
            if (crit_vr >= CRIT_CONFIRM_S) {
                snprintf(why, sizeof(why), "VR %.0fC >= %.0fC", g_state.vr_temp, lim.vr_crit_c);
                crit_chip = crit_vr = crit_power = 0;
                emergency(SysStatus::Overheat, why);
                continue;
            }
            if (crit_power >= CRIT_CONFIRM_S) {
                snprintf(why, sizeof(why), "Power %.0fW over limit", g_state.pin);
                crit_chip = crit_vr = crit_power = 0;
                emergency(SysStatus::Fault, why);
                continue;
            }
            if (++tick % 5 == 0) {
                board::Error e = board::check_faults();
                if (e != board::Error::None) {
                    emergency(SysStatus::Fault, board::error_text(e));
                    continue;
                }
            }
            if ((price::want_pause() || purifier::want_off()) && g_state.status != SysStatus::Overheat &&
                g_state.status != SysStatus::Fault) {
                if (purifier::want_off()) ESP_LOGW(TAG, "purifier %s: chips off until it's switched on", purifier::mode_name());
                else ESP_LOGW(TAG, "electricity price above the limit: chips off until it drops");
                price_paused = true;
                miner::pause(true);
                board::shutdown();
                g_state.status = SysStatus::Paused;
                continue;
            }
            if (g_state.status != SysStatus::Overheat && g_state.status != SysStatus::Fault) {
                if (wifi::in_setup_mode()) g_state.status = SysStatus::SetupAP;
                else if (!wifi::connected()) g_state.status = SysStatus::Connecting;
                else g_state.status = g_state.pool_connected ? SysStatus::Mining : SysStatus::Connecting;
            }
        } else if (price_paused) {
            // chips off: only the cooling down needs air (shutdown left the fans at 100 %),
            // except on a Bitair whose panel can't be read, which gets full air
            float d = g_state.chip_temp_max > 45 || g_state.vr_temp > 50 ? 40 : 0;
            if (purifier::mode() == purifier::Mode::Unknown && purifier::want_off()) d = purifier::fan_floor_pct();
            for (int i = 0; i < 2; i++) {
                fan::set_pct(i, d);
                g_state.fan_duty[i] = (uint8_t) d;
            }
            g_state.fan_pct = (uint8_t) d;
            g_state.status = wifi::in_setup_mode() ? SysStatus::SetupAP : SysStatus::Paused;
            if (resume_wait > 0) {
                resume_wait--;
            } else if (!price::want_pause() && !purifier::want_off()) {
                uint16_t f = cfg.autotune && cfg.tuned_freq ? cfg.tuned_freq : cfg.freq_mhz;
                uint16_t mv = cfg.autotune && cfg.tuned_mv ? cfg.tuned_mv : cfg.core_mv;
                ESP_LOGI(TAG, "%s: powering up at %u MHz", purifier::mode_name()[0] ? "purifier on" : "electricity price back under the limit", f);
                board::Error e = board::power_up(f, mv);
                snprintf(g_state.fault, sizeof(g_state.fault), "%s", e == board::Error::None ? "" : board::error_text(e));
                if (e == board::Error::None) {
                    price_paused = false;
                    resume_fails = 0;
                    g_state.status = SysStatus::Connecting;
                    miner::pause(false);
                } else if (++resume_fails < MAX_RESUME_TRIES) {
                    ESP_LOGW(TAG, "power-up after the price pause failed (%d/%d), again in %d s", resume_fails,
                             MAX_RESUME_TRIES, RESUME_WAIT_S);
                    resume_wait = RESUME_WAIT_S;
                } else {
                    // the fault retries take it from here, with their own budget: the
                    // ones used earlier in a long uptime must not leave it off for good
                    price_paused = false;
                    resume_fails = 0;
                    fault_retries = 0;
                    g_state.status = SysStatus::Fault;
                }
            }
        } else if (g_state.status == SysStatus::Overheat && overheat_retries < MAX_OVERHEAT_RETRIES) {
            fan::set_pct(0, 100);
            fan::set_pct(1, 100);
            // wait until well below the trip point, then restart lower
            if (sensors_ok && g_state.chip_temp_max < CONFIG_AF_CRIT_CHIP_TEMP - COOLDOWN_HYST_C &&
                g_state.vr_temp < lim.vr_crit_c - COOLDOWN_HYST_C && ++recovery_wait >= RECOVERY_WAIT_S) {
                recovery_wait = 0;
                overheat_retries++;
                uint16_t f = board::clamp_freq((cfg.tuned_freq ? cfg.tuned_freq : cfg.freq_mhz) - RECOVERY_FREQ_DROP);
                uint16_t mv = cfg.tuned_mv ? cfg.tuned_mv : cfg.core_mv;
                ESP_LOGW(TAG, "cooled down, restarting at %u MHz (%d/%d)", f, overheat_retries, MAX_OVERHEAT_RETRIES);
                if (board::power_up(f, mv) == board::Error::None) {
                    tuner::hold(f);  // manual mode would otherwise go straight back up
                    // only a point that actually came up becomes the new tuned point
                    if (cfg.autotune) {
                        cfg.tuned_freq = f;
                        cfg.tuned_mv = mv;
                        settings::save();
                    }
                    g_state.status = SysStatus::Mining;
                    g_state.fault[0] = 0;
                    miner::pause(false);
                }
            }
        } else if (g_state.status == SysStatus::Fault && fault_retries < MAX_FAULT_RETRIES) {
            static int wait = 0;
            if (++wait >= 30) {
                wait = 0;
                fault_retries++;
                ESP_LOGW(TAG, "retrying after fault (%d/%d)", fault_retries, MAX_FAULT_RETRIES);
                uint16_t f = cfg.tuned_freq ? cfg.tuned_freq : cfg.freq_mhz;
                uint16_t mv = cfg.tuned_mv ? cfg.tuned_mv : cfg.core_mv;
                uint16_t lower = board::clamp_freq(f - RECOVERY_FREQ_DROP);
                if (board::power_up(lower, mv) == board::Error::None) {
                    tuner::hold(lower);
                    g_state.status = SysStatus::Mining;
                    g_state.fault[0] = 0;
                    miner::pause(false);
                }
            }
        }
    }
}

namespace board {
// boards without a regulator that reports its own status
__attribute__((weak)) void log_regulator(const char *) {}
}

namespace monitor {
const char *last_emergency() { return s_note.magic == EMERGENCY_NOTE_MAGIC ? s_note.text : ""; }
uint32_t emergency_count() { return s_note.magic == EMERGENCY_NOTE_MAGIC ? s_note.count : 0; }
void start_paused() { s_start_paused = true; }
void start() { xTaskCreate(monitor_task, "monitor", 4096, NULL, 15, NULL); }
}
