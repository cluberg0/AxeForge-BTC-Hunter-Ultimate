# Contributing

Bug reports, test results from boards marked "not tested" in the README, and pull requests are all welcome.

## Before you start

Open an issue for anything bigger than a bug fix so the approach can be agreed first. Tuner behaviour and board support in particular are discussed in issues before code.

## Building

ESP-IDF v5.3.x, as in the README. Without a local toolchain, the Espressif Docker image works:

```bash
docker run --rm -v "$PWD":/project -w /project espressif/idf:v5.3.2 idf.py build
```

Other boards build from their `sdkconfig.defaults.<board>` as described in the README under Building.

## Tests

The host tests need `g++`, `make`, `libmbedtls-dev` and `libcjson-dev`:

```bash
make -C test
```

They cover the code that does not touch hardware (difficulty, coinbase and merkle building, template decoding, the payout check, SV2 framing and Noise) and the TPS546 regulator setup, run against a fake part. Add a test when you change any of that. CI runs them on every pull request, then builds the firmware for every board.

Other programs drive miners through the HTTP API, so `docs/openapi.yaml` is its contract. If you add, rename or drop a key an `/api` handler sends or reads, change the spec in the same PR. CI checks the two against each other with `python3 scripts/api_contract.py`, and `--host <miner-ip>` checks a live miner as well (GET requests only).

## Pull requests

- One change per PR. Base it on `main`.
- Title prefix: `fix:` for bugs, `enhance:` for features, `security:` for security fixes.
- Say in the description what the change does and why, in plain words.
- End with what you ran it on, for example "Tested on a NerdQaxe++ rev6 on v1.4.2". If you could not test on hardware, say so; a build-only PR is still useful.
- If users will notice the change, add a line under **Unreleased** in `RELEASE_NOTES.md`, and keep the README's board table in step. At release time the maintainer renames that heading to the version.

## Code

C++17 on ESP-IDF, C for the SV2 component. Match the style of the file you are in. Comments explain why, not what. No new dependencies without discussion.
