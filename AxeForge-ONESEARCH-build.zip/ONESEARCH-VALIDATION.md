# Validation — ONESEARCH candidate

Input: AxeForge-BTC-HUNTER-TURBO1000-UNLOCK-source.zip, source overlay and pinned upstream.
Changes: overlay/main/core/turbo.cpp/.h, one-search.patch (native tuner and web retune), UI3 HTML, build/image version, and regression tests.

## Executed host checks

- tests/turbo_phase.py: production apply/climb/phase with deterministic mock hardware. 1000 MHz in healthy simulation, voltage escalation beyond four stock steps, real budget stop, 1300mV ceiling, explicit stop and rollback, failed PLL/voltage sequencing, stock 800 MHz.
- tests/unlock_gates.py: native gates under mocked board/PSU/settings.
- tests/pll_turbo.py: 7,201 PLL reference vectors and supported 800–1000 MHz lattice.
- tests/board_turbo.py: actual board partial PLL failure and stale measurement behavior with mocks.
- tests/turbo.cpp: native turbo API and scheduler with deterministic mocks; immediate explicit start without prior lock or 30 minutes, sparse accepted samples, power/thermal/network/telemetry/storage/stop/watchdog/NVS.
- tests/image.py: synthetic image acceptance and rejection, not a real firmware.
- Node --check: embedded JavaScript syntax.
- Pinned upstream replay: native sources and final UI reproduced from patched overlay; final replay checked again after final edits.
- No ESP-IDF or Xtensa compiler available in this execution environment. DNS to GitHub unavailable from container; full compilation not executed here.
- Browser test: local Chromium navigation blocked by environment; no passing browser result claimed for this revision. GitHub hosted runner is configured to run original browser harness with UI3 disclosure expanded.

## Remaining verification

Do not install until actual OTA build/image validation passes. Test hardware on verified PSU, log /api/turbo and /api/status, confirm trials above 800 MHz and stop reason. 1000 MHz is an experimental search ceiling, not a guarantee. Archive preserves prior protections; hardware operation and performance improvement remain unverified.
